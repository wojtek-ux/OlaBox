@echo off
cd /d "%~dp0"
python.exe Main.py
pause
