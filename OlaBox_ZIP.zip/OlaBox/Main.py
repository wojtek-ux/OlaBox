import tkinter as _a
from PIL import Image as _b, ImageTk as _c
import random as _d
import os as _e
import pyautogui as _f
import time as _g

_h=_a.Tk()
_h.overrideredirect(True)
_h.attributes("-topmost", True)

_i=_h.winfo_screenwidth()
_j=_h.winfo_screenheight()

_k="PetW"

def _l(n,r=0):
    p=_e.path.join(_k,n)
    i=_b.open(p).convert("RGBA")
    i=i.resize((200,200))
    if r!=0:i=i.rotate(r,expand=True)
    return _c.PhotoImage(i)

_m=_l("petwalk1.png")
_n=_l("petwalk2.png")
_o=_l("petwalk1.png",90)

_p=_m

_q=_a.Label(_h,image=_p,bg="black")
_q.pack()

_r=_a.Label(_h,text="",fg="white",bg="black",font=("Arial",10))
_r.place(x=0,y=0)

_s=_d.randint(0,_i-200)
_t=_d.randint(0,_j-200)

_u=2
_v=2

_w=False
_x=False
_y=True
_z=0

def _A(img):
    global _p
    _p=img
    _q.config(image=_p)

def _B():
    _r.config(text="🖱️ Kliknij PPM aby otworzyć panel admina")
    _h.after(3000,_C)

def _C():
    global _y
    _y=False
    _r.config(text="")

def _D():
    global _z
    if not _w and not _x and not _y:
        if _z==0:_A(_m);_z=1
        else:_A(_n);_z=0
    _h.after(300,_D)

def _E():
    global _s,_t,_u,_v
    if not _w and not _x and not _y:
        _s+=_u
        _t+=_v
        if _s<=0 or _s>=_i-200:_u*=-1
        if _t<=0 or _t>=_j-200:_v*=-1
    _h.geometry(f"200x200+{_s}+{_t}")
    _h.after(30,_E)

def _F(e):
    global _w
    _w=True

def _G(e):
    global _s,_t
    _s=e.x_root-100
    _t=e.y_root-100

def _H(e):
    global _w,_x
    _w=False
    if _t<200:_x=True;_I()

def _I():
    global _t,_x
    if _t<_j-200:
        _t+=15
        _h.geometry(f"200x200+{_s}+{_t}")
        _h.after(20,_I)
    else:_x=False;_J()

def _J():
    _A(_o)
    _h.after(3000,_K)

def _K():
    pass

def _L(txt):
    _g.sleep(0.3)
    _f.press("win")
    _g.sleep(0.5)
    _f.write(txt,interval=0.05)
    _g.sleep(0.5)
    _f.press("enter")

def _M():_L("Ustawienia")
def _N():_L("YouTube")
def _O():_L("Discord")

def _P(e=None):
    global _y
    _y=True
    p=_a.Toplevel()
    p.title("🐶 Panel Admina")
    p.geometry("260x300")

    def _Q():
        global _y
        _y=False
        p.destroy()

    _a.Label(p,text="Co zrobić z pieskiem?").pack(pady=10)

    def _R():
        global _u,_v
        _u*=2;_v*=2

    def _S():
        global _u,_v
        _u=max(1,_u//2)
        _v=max(1,_v//2)

    def _T():
        global _s,_t
        _s=_d.randint(0,_i-200)
        _t=_d.randint(0,_j-200)

    def _U():
        _h.destroy()

    _a.Button(p,text="⚡ Szybciej",command=_R).pack(fill="x")
    _a.Button(p,text="🐢 Wolniej",command=_S).pack(fill="x")
    _a.Button(p,text="📍 Teleport",command=_T).pack(fill="x")
    _a.Button(p,text="⚙️ Ustawienia PC",command=_M).pack(fill="x")
    _a.Button(p,text="▶️ YouTube",command=_N).pack(fill="x")
    _a.Button(p,text="💬 Discord",command=_O).pack(fill="x")
    _a.Button(p,text="❌ Zamknij program",command=_U).pack(fill="x")

    p.protocol("WM_DELETE_WINDOW",_Q)

_q.bind("<Button-3>",_P)
_q.bind("<Button-1>",_F)
_q.bind("<B1-Motion>",_G)
_q.bind("<ButtonRelease-1>",_H)

_B()
_D()
_E()

_h.mainloop()